const NavBar = () => {
    return (
      <header>
        <h1>NavBar</h1>
      </header>
    );
  };
  
  export default NavBar;